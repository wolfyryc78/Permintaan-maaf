/**
 * MAIN.JS - Interaksi Utama Website Permintaan Maaf
 * Termasuk: Transisi Halaman Halus, Bunga Halaman 3, Scroll Garis Halaman 4, Reveal Halaman 6
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Inisialisasi Transisi Halaman Masuk
  requestAnimationFrame(() => {
    document.body.classList.add('page-loaded');
  });

  // 2. Intersepsi Navigasi untuk Transisi Halaman Keluar yang Halus
  document.querySelectorAll('a').forEach(link => {
    const href = link.getAttribute('href');
    // Abaikan anchor internal (#) atau link eksternal target _blank
    if (href && !href.startsWith('#') && !href.startsWith('javascript:') && link.target !== '_blank') {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        document.body.classList.remove('page-loaded');
        document.body.classList.add('page-exit');
        setTimeout(() => {
          window.location.href = href;
        }, 320);
      });
    }
  });

  // =========================================================================
  // HALAMAN 3: Interaksi Bunga (Grayscale ke Warna Penuh)
  // =========================================================================
  const flowerBox = document.getElementById('flower-interactive-box');
  const perspectiveContainer = document.getElementById('perspective-container');
  const colorRevelationText = document.getElementById('color-revelation-text');
  const tapHint = document.getElementById('tap-hint');

  if (flowerBox && perspectiveContainer) {
    let isBloomed = false;

    const triggerBloom = () => {
      if (isBloomed) return;
      isBloomed = true;

      // Hapus mode grayscale dari container
      perspectiveContainer.classList.remove('grayscale-mode');
      
      // Beri tanda mekar pada slot bunga
      const flowerSlot = flowerBox.querySelector('.flower-slot');
      if (flowerSlot) flowerSlot.classList.add('bloomed');

      // Sembunyikan hint ketuk
      if (tapHint) {
        tapHint.style.opacity = '0';
      }

      // Tampilkan teks lanjutan secara bertahap
      if (colorRevelationText) {
        setTimeout(() => {
          colorRevelationText.classList.add('visible');
        }, 500);
      }

      // Berikan getaran haptic halus pada smartphone jika didukung
      if (navigator.vibrate) {
        navigator.vibrate(40);
      }
    };

    flowerBox.addEventListener('click', triggerBloom);
    flowerBox.addEventListener('touchend', (e) => {
      e.preventDefault();
      triggerBloom();
    });
  }

  // =========================================================================
  // HALAMAN 4: Garis Perasaan Vertikal (Scroll Depth Progress)
  // =========================================================================
  const lineFill = document.getElementById('story-line-fill');
  const storyWrapper = document.getElementById('scroll-story-wrapper');
  const storyBlocks = document.querySelectorAll('.story-block');

  if (lineFill && storyWrapper) {
    const updateScrollProgress = () => {
      const rect = storyWrapper.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      
      // Hitung seberapa jauh wrapper telah di-scroll
      const totalHeight = storyWrapper.offsetHeight;
      const visibleTop = windowHeight * 0.75 - rect.top;
      let percentage = (visibleTop / totalHeight) * 100;
      
      percentage = Math.max(0, Math.min(100, percentage));
      lineFill.style.height = `${percentage}%`;

      // Aktifkan blok yang sedang terbaca
      storyBlocks.forEach(block => {
        const bRect = block.getBoundingClientRect();
        if (bRect.top < windowHeight * 0.8 && bRect.bottom > windowHeight * 0.2) {
          block.classList.add('active');
        }
      });
    };

    window.addEventListener('scroll', updateScrollProgress, { passive: true });
    window.addEventListener('resize', updateScrollProgress);
    updateScrollProgress(); // Initial check
  }

  // =========================================================================
  // HALAMAN 6: Staggered Reveal untuk Galeri Ilustrasi
  // =========================================================================
  const galleryCards = document.querySelectorAll('.gallery-card');
  if (galleryCards.length > 0) {
    galleryCards.forEach((card, index) => {
      setTimeout(() => {
        card.classList.add('revealed');
      }, 350 * (index + 1));
    });
  }
});
