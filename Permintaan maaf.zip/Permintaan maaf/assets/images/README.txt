===================================================================
PETUNJUK PENGGANTIAN GAMBAR / ASET (ASSETS/IMAGES)
===================================================================

Kamu bisa mengganti gambar-gambar default dengan foto/gambar aslimu.
Cukup simpan gambar kamu di dalam folder ini (`assets/images/`) dengan nama file yang sesuai:

1. `old-website.png` (atau `.svg` / `.jpg`)
   -> Screenshot website ulang tahun lama yang pernah kamu buat untuk dia (Halaman 2).

2. `flower.png` (atau `.svg` / `.jpg`)
   -> Gambar bunga interaktif untuk trigger perubahan warna (Halaman 3).

3. `illustration-1.png` (atau `.svg` / `.jpg`)
   -> Gambar Es Krim favorit dia (Halaman 6).

4. `illustration-2.png` (atau `.svg` / `.jpg`)
   -> Gambar Kucing kesukaan dia (Halaman 6).

5. `illustration-3.png` (atau `.svg` / `.jpg`)
   -> Gambar Karakter/Tema Bocchi the Rock (Hitori Gotoh) kesukaan dia (Halaman 6).

6. `illustration-quiet.png` (atau `.svg` / `.jpg`)
   -> Gambar satu ikon tenang/damai (Halaman 7).

* Catatan: Jika format gambar kamu adalah .png atau .jpg, kamu bisa langsung mengubah ekstensi file di baris `src="..."` pada file HTML terkait, atau menggunakan format nama yang sama.
===================================================================
