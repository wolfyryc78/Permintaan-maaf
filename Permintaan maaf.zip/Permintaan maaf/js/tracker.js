/**
 * TRACKER.JS - Logika Tombol Penentuan & Integrasi Google Sheets (Halaman 5)
 * =========================================================================
 * PANDUAN:
 * 1. Ganti GOOGLE_SCRIPT_URL di bawah dengan Web App URL dari Google Apps Script kamu.
 * 2. Kamu bisa bebas mengubah kalimat pesan pop-up pada objek PESAN_TIDAK.
 * =========================================================================
 */

// !!! GANTI DENGAN URL GOOGLE APPS SCRIPT WEB APP MILIKMU !!!
const GOOGLE_SCRIPT_URL = "ISI_DENGAN_URL_GOOGLE_APPS_SCRIPT_KAMU";

// Pesan popup yang muncul berurutan saat tombol "Tidak" diklik
const PESAN_TIDAK = {
  1: "Aku paham kalau kamu masih ragu... tapi aku sungguh-sungguh ingin memperbaiki semuanya.",
  2: "Nggak apa-apa, aku tahu lukanya nggak gampang sembuh. Tapi tolong beri aku satu kesempatan kecil saja...",
  3: "Baiklah... aku dengar dan aku hargai keputusanmu. Terima kasih ya sudah mau mendengarkan sampai sini."
};

document.addEventListener('DOMContentLoaded', () => {
  // Inisialisasi transisi halaman masuk
  requestAnimationFrame(() => {
    document.body.classList.add('page-loaded');
  });

  const btnYes = document.getElementById('btn-yes');
  const btnNo = document.getElementById('btn-no');
  const sendingOverlay = document.getElementById('sending-overlay');

  if (!btnYes || !btnNo) return;

  let noClickCount = 0;
  const maxNoClicks = 3;

  // Sedikit acak posisi tombol Ya & Tidak saat pertama kali dimuat
  const randomizeButtonLayout = () => {
    const actionsContainer = document.querySelector('.decision-actions');
    if (actionsContainer && Math.random() > 0.5) {
      // Tukar urutan tampilan (fleksibel)
      actionsContainer.style.flexDirection = 'row-reverse';
    }
  };
  randomizeButtonLayout();

  // Fungsi memunculkan pop-up teks di koordinat acak
  const showRandomPopup = (message) => {
    const bubble = document.createElement('div');
    bubble.className = 'popup-bubble';
    bubble.textContent = message;

    // Tentukan posisi acak di dalam batas aman layar (15% - 75% viewport)
    const padding = 20;
    const maxX = window.innerWidth - 280;
    const maxY = window.innerHeight - 150;

    const randomX = Math.max(padding, Math.min(maxX, Math.floor(Math.random() * (maxX - padding) + padding)));
    const randomY = Math.max(padding + 60, Math.min(maxY, Math.floor(Math.random() * (maxY - padding) + padding)));

    bubble.style.left = `${randomX}px`;
    bubble.style.top = `${randomY}px`;

    document.body.appendChild(bubble);

    // Hapus elemen setelah animasi selesai (3 detik)
    setTimeout(() => {
      if (bubble && bubble.parentNode) {
        bubble.parentNode.removeChild(bubble);
      }
    }, 3000);
  };

  // Fungsi Pengiriman Data ke Google Sheets
  const sendResponseToGoogleSheets = async (choice, details) => {
    const payload = {
      timestamp: new Date().toISOString(),
      choice: choice,
      details: details,
      userAgent: navigator.userAgent
    };

    // Jika URL belum disetel oleh user, langsung fallback tanpa error
    if (!GOOGLE_SCRIPT_URL || GOOGLE_SCRIPT_URL.includes("ISI_DENGAN_URL")) {
      console.warn("Google Apps Script URL belum disetel. Melewati pencatatan.");
      return;
    }

    try {
      // Kirim via fetch dengan mode no-cors untuk kompatibilitas Google Apps Script
      await fetch(GOOGLE_SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.error("Gagal mengirim ke Google Sheets:", err);
    }
  };

  // Pengalihan halaman aman dengan fallback batas waktu
  const navigateSafely = (targetUrl) => {
    if (sendingOverlay) sendingOverlay.classList.add('active');
    
    // Beri waktu sejenak untuk request terkirim lalu redirect
    setTimeout(() => {
      document.body.classList.remove('page-loaded');
      document.body.classList.add('page-exit');
      setTimeout(() => {
        window.location.href = targetUrl;
      }, 300);
    }, 600);
  };

  // ==========================================
  // EVENT LISTENER: Tombol "Ya"
  // ==========================================
  btnYes.addEventListener('click', async () => {
    btnYes.disabled = true;
    btnNo.disabled = true;

    // Catat ke Google Sheets
    sendResponseToGoogleSheets('Ya', `Dipilih setelah ${noClickCount} kali klik Tidak`);

    // Alihkan ke Halaman 6
    navigateSafely('page6.html');
  });

  // ==========================================
  // EVENT LISTENER: Tombol "Tidak"
  // ==========================================
  btnNo.addEventListener('click', async () => {
    noClickCount++;

    // Tampilkan pesan popup sesuai urutan klik
    const currentMessage = PESAN_TIDAK[noClickCount] || PESAN_TIDAK[3];
    showRandomPopup(currentMessage);

    // Dorongan halus: Tombol "Ya" menjadi sedikit lebih besar & menonjol
    const currentScale = 1 + (noClickCount * 0.12);
    btnYes.style.transform = `scale(${currentScale})`;
    btnYes.style.boxShadow = `0 ${6 + noClickCount * 4}px ${18 + noClickCount * 6}px rgba(92, 149, 181, ${0.35 + noClickCount * 0.15})`;

    // Jika sudah mencapai 3x klik
    if (noClickCount >= maxNoClicks) {
      btnNo.disabled = true;
      btnYes.disabled = true;

      // Catat ke Google Sheets
      sendResponseToGoogleSheets('Tidak', 'Mencapai batas 3 kali klik Tidak');

      // Alihkan ke Halaman 7 (Penutup Damai) setelah pop-up terakhir terbaca sejenak
      setTimeout(() => {
        navigateSafely('page7.html');
      }, 1500);
    }
  });
});
